package dao;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import javax.swing.JOptionPane;

public class tables {
    
    public static void main(String[] args) {
        Connection con = null;
        Statement st = null;
        
        try {
            con = ConnectionProvider.getCon();
            st = con.createStatement();
            
            // Create userdetails table if it does not exist
            if (!tableExists(st, "userdetails")) {
                st.executeUpdate(
                    "CREATE TABLE userdetails (" +
                    "id VARCHAR(20) PRIMARY KEY, " +  // Assuming id like "CA202300072"
                    "name VARCHAR(255) NOT NULL, " +
                    "gender VARCHAR(50) NOT NULL, " +
                    "email VARCHAR(255) NOT NULL, " +
                    "section VARCHAR(20) NOT NULL, " +
                    "studentnumber VARCHAR(20) NOT NULL" +
                    "campus VARCHAR(20) NOT NULL" +
                    "imagename VARCHAR(100)" +
                    ");"
                );
            }
            
            // Create useattendance table if it does not exist
            if (!tableExists(st, "userattendance")) {
                st.executeUpdate(
                    "CREATE TABLE useattendance (" +
                    "attendance_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "student_id VARCHAR(20), " +  // Links to id in userdetails
                    "date DATE NOT NULL, " +
                    "status VARCHAR(10) NOT NULL, " +  // e.g., Present/Absent
                    "FOREIGN KEY (student_id) REFERENCES userdetails(id)" +
                    ");"
                );
            }
            
            JOptionPane.showMessageDialog(null, "Tables checked/created successfully");
            
        } catch(Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        } finally {
            try {
                if (st != null) st.close();
                if (con != null) con.close();
            } catch(Exception ex) {
                ex.printStackTrace();
            }
        }
    }
    
    private static boolean tableExists(Statement st, String tableName) throws Exception {
        ResultSet resultSet = st.executeQuery("SHOW TABLES LIKE '" + tableName + "'");
        return resultSet.next();
    }
}
